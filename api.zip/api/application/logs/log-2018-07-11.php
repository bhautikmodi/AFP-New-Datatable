<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-07-11 12:22:06 --> Severity: Notice --> Use of undefined constant ACTIVE_GROUP - assumed 'ACTIVE_GROUP' C:\wamp64\www\AFP_NEW\api\application\controllers\Login_user.php 19
ERROR - 2018-07-11 12:22:23 --> Severity: Notice --> Use of undefined constant ACTIVE_GROUP - assumed 'ACTIVE_GROUP' C:\wamp64\www\AFP_NEW\api\application\controllers\Login_user.php 19
ERROR - 2018-07-11 12:23:27 --> Severity: Notice --> Use of undefined constant ACTIVE_GROUP - assumed 'ACTIVE_GROUP' C:\wamp64\www\AFP_NEW\api\application\controllers\Login_user.php 19
ERROR - 2018-07-11 16:29:38 --> Severity: Notice --> Array to string conversion C:\wamp64\www\AFP_NEW\api\application\controllers\Salesuser.php 20
